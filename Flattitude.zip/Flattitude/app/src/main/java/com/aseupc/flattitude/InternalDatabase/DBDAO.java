package com.aseupc.flattitude.InternalDatabase;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Jordi on 19/10/2015.
 */
public class DBDAO {

    protected SQLiteDatabase database;
    private DataBaseHelper dbHelper;
    private Context mContext;

    public DBDAO(Context context) {
        this.mContext = context;
        dbHelper = DataBaseHelper.getHelper(mContext);
        open();
    }

    public void open() throws SQLException {
        if(dbHelper == null)
            dbHelper = DataBaseHelper.getHelper(mContext);
        database = dbHelper.getWritableDatabase();
    }

    protected String formatDate(Date date){
        if (date == null)
            return "";
       else  {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        return df.format(date);}
    }

    protected Date parseDate(String date){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            return df.parse(date); //It have to be verified which format the database returns!
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    protected SimpleDateFormat parseSimpleDate(String date){
        SimpleDateFormat df = new SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy");
        return df; //It have to be verified which format the database returns!
    }
    protected int formatBoolean(boolean b){
        return b ? 1 : 0;
    }

    protected boolean parseBoolean(int x){
        return x != 0;
    }
}
